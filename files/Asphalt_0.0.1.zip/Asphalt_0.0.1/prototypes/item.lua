data:extend({
  {
    type = "item",
    name = "asphalt",
    icon = "__base__/graphics/icons/concrete.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "terrain",
    order = "b[asphalt]",
    stack_size = 500,
    place_as_tile =
    {
      result = "asphalt",
      condition_size = 4,
      condition = { "water-tile" }
    }
  }
})
