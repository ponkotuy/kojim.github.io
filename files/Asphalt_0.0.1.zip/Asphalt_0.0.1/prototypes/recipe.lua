data:extend({
  {
    type = "recipe",
    name = "asphalt",
    energy_required = 10,
    enabled = false,
    category = "crafting-with-fluid",
    ingredients =
    {
      {"concrete", 5},
      {type="fluid", name="heavy-oil", amount=1}
    },
    result= "asphalt",
    result_count = 10
  }
})
