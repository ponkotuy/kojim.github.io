data:extend({
  {
    type = "technology",
    name = "asphalt",
    icon = "__base__/graphics/technology/concrete.png",
    effects = {
      {
        type = "unlock-recipe",
        recipe = "asphalt"
      }
    },
    prerequisites = {
      "concrete"
    },
    unit = {
      count = 20,
      ingredients = {
        {"science-pack-1", 1},
        {"science-pack-2", 1}
      },
      time = 20
    }
  }
})
